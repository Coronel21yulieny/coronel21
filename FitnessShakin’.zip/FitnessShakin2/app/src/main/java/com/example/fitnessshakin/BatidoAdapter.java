package com.example.fitnessshakin;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BatidoAdapter extends RecyclerView.Adapter {
    public BatidoAdapter(Object p01) {


        class batidoadapter {

            private Batidos[] batidos;

            public void BatidoAdapter(Batidos[] batidos) {
                this.batidos = batidos;
            }

            class BatidoViewHolder extends RecyclerView.ViewHolder {
                public TextView nombreTextView;
                public TextView ingredientesTextView;
                public ImageView imagenImageView;

                public BatidoViewHolder(View v) {
                    super(v);
                    nombreTextView = v.findViewById(R.id.nombreTextView);
                    ingredientesTextView = v.findViewById(R.id.imagenImageView);
                    imagenImageView = v.findViewById(R.id.imagenImageView);
                }
            }


            public void onBindViewHolder(@NonNull BatidoViewHolder holder, int position) {
                Batidos batido = batidos[position];
                holder.nombreTextView.setText(batido.getNombre());
                holder.ingredientesTextView.setText(batido.getIngredientes());
                holder.imagenImageView.setImageResource(batido.getImagenResId());
            }

        }
        class batidoadapterImpl extends batidoadapter {}
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public interface BatidoViewHolder {
    }
}
