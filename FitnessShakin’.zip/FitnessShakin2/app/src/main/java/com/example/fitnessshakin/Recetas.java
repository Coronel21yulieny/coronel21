package com.example.fitnessshakin;


import java.util.List;

public class Recetas {
        private String nombre;
        private List<Batidos> batidos;

        public Recetas(String nombre, List<Batidos> batidos) {
            this.nombre = nombre;
            this.batidos = batidos;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public List<Batidos> getBatidos() {
            return batidos;
        }

        public void setBatidos(List<Batidos> batidos) {
            this.batidos = batidos;
        }
    }

