package com.example.fitnessshakin;

public @interface Batidos_Saludables {


    public class Batido {
        public static final Batido[] BATIDOS_SALUDABLES = {
                new Batido("Batido de Espinacas y Piña", "Ingredientes: espinacas, piña, agua de coco.", R.drawable.batidos_espinacas_pina),
                new Batido("Batido de Bayas y Aguacate", "Ingredientes: bayas congeladas (fresas, moras, arándanos), aguacate, leche de almendras.", R.drawable.batidos_bayas_aguacate),
                new Batido("Batido de Mango y Zanahoria", "Ingredientes: mango, zanahoria, jugo de naranja.", R.drawable.batidos_mango_zanahoria)
        };

        private String nombre;
        private String ingredientes;
        private int imagenResId;

        public Batido(String nombre, String ingredientes, int imagenResId) {
            this.nombre = nombre;
            this.ingredientes = ingredientes;
            this.imagenResId = imagenResId;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getIngredientes() {
            return ingredientes;
        }

        public void setIngredientes(String ingredientes) {
            this.ingredientes = ingredientes;
        }

        public int getImagenResId() {
            return imagenResId;
        }

        public void setImagenResId(int imagenResId) {
            this.imagenResId = imagenResId;
        }
    }

}
